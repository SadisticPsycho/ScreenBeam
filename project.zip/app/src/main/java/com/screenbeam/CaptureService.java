package com.screenbeam;

import android.app.*;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.view.Surface;
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;

public class CaptureService extends Service {
    static volatile boolean running = false;
    static volatile String status = "";
    MediaProjection projection;
    VirtualDisplay display;
    MediaCodec codec;
    Socket socket;

    public IBinder onBind(Intent i) { return null; }

    public int onStartCommand(Intent i, int flags, int id) {
        if (i == null || "STOP".equals(i.getAction())) {
            stopCasting();
            return START_NOT_STICKY;
        }
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(new NotificationChannel("cast", "Casting", NotificationManager.IMPORTANCE_LOW));
        Notification.Builder nb = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "cast") : new Notification.Builder(this);
        Notification n = nb.setContentTitle("ScreenBeam is casting").setSmallIcon(android.R.drawable.ic_media_play).build();
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        else startForeground(1, n);

        final String ip = i.getStringExtra("ip");
        final int w = i.getIntExtra("w", 720), h = i.getIntExtra("h", 1280), dpi = i.getIntExtra("dpi", 320);
        int code = i.getIntExtra("code", 0);
        Intent data = i.getParcelableExtra("data");
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = mpm.getMediaProjection(code, data);
        projection.registerCallback(new MediaProjection.Callback() {
            public void onStop() { stopCasting(); }
        }, new Handler(Looper.getMainLooper()));
        running = true;
        status = "Connecting…";
        new Thread(() -> stream(ip, w, h, dpi)).start();
        return START_NOT_STICKY;
    }

    void stream(String ip, int w, int h, int dpi) {
        try {
            socket = new Socket();
            socket.setTcpNoDelay(true);
            socket.connect(new InetSocketAddress(ip, MainActivity.PORT), 5000);
            DataOutputStream out = new DataOutputStream(new BufferedOutputStream(socket.getOutputStream(), 1 << 16));
            out.writeInt(w);
            out.writeInt(h);
            out.flush();

            MediaFormat f = MediaFormat.createVideoFormat("video/avc", w, h);
            f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface);
            f.setInteger(MediaFormat.KEY_BIT_RATE, 10_000_000);
            f.setInteger(MediaFormat.KEY_FRAME_RATE, 30);
            f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1);
            f.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100000);
            if (Build.VERSION.SDK_INT >= 23) f.setInteger(MediaFormat.KEY_PRIORITY, 0);
            if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1);
            codec = MediaCodec.createEncoderByType("video/avc");
            codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
            Surface s = codec.createInputSurface();
            codec.start();
            display = projection.createVirtualDisplay("ScreenBeam", w, h, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, s, null, null);
            status = "Casting live ●";

            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            while (running) {
                int i = codec.dequeueOutputBuffer(info, 100000);
                if (i >= 0) {
                    ByteBuffer b = codec.getOutputBuffer(i);
                    byte[] d = new byte[info.size];
                    b.position(info.offset);
                    b.get(d);
                    codec.releaseOutputBuffer(i, false);
                    out.writeInt(d.length);
                    out.writeByte(info.flags);
                    out.write(d);
                    out.flush();
                }
            }
        } catch (Exception e) {
            if (running) status = "Error: " + e.getMessage();
        } finally {
            stopCasting();
        }
    }

    synchronized void stopCasting() {
        running = false;
        try { if (display != null) display.release(); } catch (Exception e) {}
        display = null;
        try { if (codec != null) { codec.stop(); codec.release(); } } catch (Exception e) {}
        codec = null;
        try { if (socket != null) socket.close(); } catch (Exception e) {}
        socket = null;
        MediaProjection p = projection;
        projection = null;
        try { if (p != null) p.stop(); } catch (Exception e) {}
        if (!status.startsWith("Error")) status = "Stopped";
        stopSelf();
    }
}
