package com.screenbeam;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.text.method.DigitsKeyListener;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.util.Collections;

public class MainActivity extends Activity {
    static final int PORT = 5000, REQ = 42;
    final Handler ui = new Handler(Looper.getMainLooper());
    TextView actionBtn, statusTv, ipView;
    EditText ipEdit;
    View overlay;
    volatile Surface surface;
    volatile boolean alive = true;
    ServerSocket server;

    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        UiModeManager um = (UiModeManager) getSystemService(UI_MODE_SERVICE);
        if (um.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) buildReceiver();
        else buildSender();
    }

    // ---------- UI helpers ----------
    int dp(int v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics()); }

    GradientDrawable bg(int c1, int c2, float r) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(r);
        return g;
    }

    TextView tv(String t, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setGravity(Gravity.CENTER);
        return v;
    }

    TextView button(String t) {
        TextView b = tv(t, 18, Color.WHITE, true);
        b.setPadding(dp(24), dp(18), dp(24), dp(18));
        b.setBackground(bg(0xFF7C3AED, 0xFF06B6D4, dp(32)));
        b.setClickable(true);
        return b;
    }

    LinearLayout.LayoutParams lp(int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(top);
        return p;
    }

    // ---------- PHONE: sender ----------
    void buildSender() {
        ScrollView root = new ScrollView(this);
        root.setBackground(bg(0xFF0F172A, 0xFF2E1065, 0));
        root.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER_HORIZONTAL);
        col.setPadding(dp(24), dp(72), dp(24), dp(24));
        root.addView(col, new FrameLayout.LayoutParams(-1, -2));

        col.addView(tv("📺", 56, Color.WHITE, false), lp(0));
        col.addView(tv("ScreenBeam", 30, Color.WHITE, true), lp(8));
        col.addView(tv("Mirror your phone to your TV", 15, 0xFF94A3B8, false), lp(4));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(20), dp(20), dp(20), dp(20));
        card.setBackground(bg(0x33FFFFFF, 0x1AFFFFFF, dp(24)));
        card.addView(tv("TV ADDRESS", 12, 0xFFA78BFA, true), lp(0));
        ipEdit = new EditText(this);
        ipEdit.setHint("192.168.x.x");
        ipEdit.setHintTextColor(0xFF64748B);
        ipEdit.setTextColor(Color.WHITE);
        ipEdit.setTextSize(26);
        ipEdit.setGravity(Gravity.CENTER);
        ipEdit.setKeyListener(DigitsKeyListener.getInstance("0123456789."));
        ipEdit.setText(getSharedPreferences("p", 0).getString("ip", ""));
        card.addView(ipEdit, lp(8));
        statusTv = tv("Ready", 14, 0xFF94A3B8, false);
        card.addView(statusTv, lp(8));
        col.addView(card, lp(36));

        actionBtn = button("Start casting");
        col.addView(actionBtn, lp(28));
        col.addView(tv("Turn on your phone hotspot (5 GHz), connect the TV to it, and type the address shown on the TV.",
                13, 0xFF64748B, false), lp(28));
        setContentView(root);

        actionBtn.setOnClickListener(v -> {
            if (CaptureService.running) {
                startService(new Intent(this, CaptureService.class).setAction("STOP"));
            } else {
                String ip = ipEdit.getText().toString().trim();
                if (ip.isEmpty()) { statusTv.setText("Enter the TV address first"); return; }
                getSharedPreferences("p", 0).edit().putString("ip", ip).apply();
                MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(m.createScreenCaptureIntent(), REQ);
            }
        });
        ui.post(new Runnable() {
            public void run() {
                actionBtn.setText(CaptureService.running ? "Stop casting" : "Start casting");
                if (!CaptureService.status.isEmpty()) statusTv.setText(CaptureService.status);
                ui.postDelayed(this, 500);
            }
        });
    }

    protected void onActivityResult(int rc, int res, Intent data) {
        super.onActivityResult(rc, res, data);
        if (rc != REQ || res != RESULT_OK) return;
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        float s = Math.min(1f, 1920f / Math.max(dm.widthPixels, dm.heightPixels));
        int w = ((int) (dm.widthPixels * s)) / 16 * 16, h = ((int) (dm.heightPixels * s)) / 16 * 16;
        Intent i = new Intent(this, CaptureService.class).setAction("START")
                .putExtra("code", res).putExtra("data", data)
                .putExtra("ip", ipEdit.getText().toString().trim())
                .putExtra("w", w).putExtra("h", h).putExtra("dpi", dm.densityDpi);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    // ---------- TV: receiver ----------
    void buildReceiver() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        SurfaceView sv = new SurfaceView(this);
        root.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        sv.getHolder().addCallback(new SurfaceHolder.Callback() {
            public void surfaceCreated(SurfaceHolder h) { surface = h.getSurface(); }
            public void surfaceChanged(SurfaceHolder h, int f, int w, int hh) {}
            public void surfaceDestroyed(SurfaceHolder h) { surface = null; }
        });

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setBackground(bg(0xFF0F172A, 0xFF2E1065, 0));
        col.addView(tv("📺", 72, Color.WHITE, false), lp(0));
        col.addView(tv("ScreenBeam", 44, Color.WHITE, true), lp(8));
        col.addView(tv("Waiting for your phone…", 22, 0xFF94A3B8, false), lp(8));
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(48), dp(24), dp(48), dp(24));
        card.setBackground(bg(0x33FFFFFF, 0x1AFFFFFF, dp(28)));
        card.addView(tv("TYPE THIS ON YOUR PHONE", 14, 0xFFA78BFA, true), lp(0));
        ipView = tv(myIp(), 48, Color.WHITE, true);
        card.addView(ipView, lp(8));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
        cp.topMargin = dp(36);
        col.addView(card, cp);
        col.addView(tv("Connect this TV to your phone's hotspot first", 16, 0xFF64748B, false), lp(28));
        overlay = col;
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        ui.post(new Runnable() {
            public void run() {
                ipView.setText(myIp());
                ui.postDelayed(this, 3000);
            }
        });
        new Thread(this::serve).start();
    }

    String myIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces()))
                for (InetAddress a : Collections.list(ni.getInetAddresses()))
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address) return a.getHostAddress();
        } catch (Exception e) {}
        return "Not connected";
    }

    void serve() {
        try {
            server = new ServerSocket();
            server.setReuseAddress(true);
            server.bind(new InetSocketAddress(PORT));
            while (alive) handle(server.accept());
        } catch (Exception e) {}
    }

    void drain(MediaCodec dec, MediaCodec.BufferInfo bi) {
        int o;
        while ((o = dec.dequeueOutputBuffer(bi, 0)) >= 0) dec.releaseOutputBuffer(o, true);
    }

    void handle(Socket c) {
        MediaCodec dec = null;
        try {
            c.setTcpNoDelay(true);
            DataInputStream in = new DataInputStream(new BufferedInputStream(c.getInputStream(), 1 << 16));
            int w = in.readInt(), h = in.readInt();
            while (surface == null && alive) Thread.sleep(50);
            ui.post(() -> overlay.setVisibility(View.GONE));
            MediaFormat f = MediaFormat.createVideoFormat("video/avc", w, h);
            f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 << 21);
            if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1);
            dec = MediaCodec.createDecoderByType("video/avc");
            dec.configure(f, surface, null, 0);
            dec.start();
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            long pts = 0;
            while (alive) {
                int len = in.readInt();
                int flags = in.readByte();
                byte[] d = new byte[len];
                in.readFully(d);
                int idx;
                while ((idx = dec.dequeueInputBuffer(5000)) < 0) drain(dec, bi);
                ByteBuffer ib = dec.getInputBuffer(idx);
                ib.clear();
                ib.put(d);
                dec.queueInputBuffer(idx, 0, len, pts, flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG);
                pts += 33333;
                drain(dec, bi);
            }
        } catch (Exception e) {
        } finally {
            try { if (dec != null) { dec.stop(); dec.release(); } } catch (Exception e) {}
            try { c.close(); } catch (Exception e) {}
            ui.post(() -> overlay.setVisibility(View.VISIBLE));
        }
    }

    protected void onDestroy() {
        alive = false;
        try { if (server != null) server.close(); } catch (Exception e) {}
        super.onDestroy();
    }
}
